package com.upgrad.hotel_room_booking.Payment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
