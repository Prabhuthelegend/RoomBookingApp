rootProject.name = "Eureka-Server"
