rootProject.name = "Booking"
