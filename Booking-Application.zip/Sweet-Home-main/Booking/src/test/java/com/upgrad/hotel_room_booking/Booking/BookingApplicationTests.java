package com.upgrad.hotel_room_booking.Booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
